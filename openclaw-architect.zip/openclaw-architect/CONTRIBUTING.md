# Contributing

Thank you for considering a contribution. This is an early-stage scaffold;
the most useful PRs are the ones that turn stubs into working features.

## Setup

```bash
git clone https://github.com/joonnyip/openclaw-architect.git
cd openclaw-architect
pnpm install
pnpm test     # parser tests should pass
```

## Development loop

```bash
# Generate fresh architecture data
pnpm architect scan ./examples/sample-openclaw-project --out architecture.json

# Run the web app against it
cp architecture.json packages/web/public/architecture.json
pnpm dev   # opens http://localhost:5173
```

## Where to start

In rough difficulty order:

### Easy

- **Add a parser test.** `packages/parser/tests/` uses Node's built-in
  `node:test`. Pick any function in `packages/parser/src/` that lacks
  coverage.
- **Improve a discovery heuristic.** Edit
  `packages/parser/src/discovery.ts`. Add a new `Pattern` and a couple
  of test directories under `examples/sample-openclaw-project/`.
- **Implement an export format.** Two stubs are waiting in
  `packages/parser/src/exporters.ts`: `exportPlantUml` and
  `exportStandaloneHtml`. Each is one self-contained function.

### Medium

- **Implement one of the stubbed visualization views.** Each is a React
  component in `packages/web/src/components/` reading from the same
  `Architecture` document. Pick one from `docs/ROADMAP.md` —
  Plugin Architecture and Multi-Agent Map are probably the
  best-bang-for-the-buck.
- **Make the standalone HTML actually downloadable as a single self-contained
  diagram.** Currently it loads JSON externally; could be embedded.

### Hard

- **TypeScript AST parsing.** Add `packages/parser/src/parsers/typescript.ts`
  using `@typescript-eslint/parser`. Output should be additional
  `Component`s with populated `sourceLocation` and additional `imports`
  edges. See `docs/ROADMAP.md` for design notes.
- **Python AST parsing** — the same shape, using Python's `ast` module.
  Probably needs a small Python helper invoked via subprocess from the
  parser.

## PR guidelines

- One concern per PR. Easier to review and revert if needed.
- Update the README's status table if your PR moves a row from 🟡 / ❌
  to ✅.
- If you add a new format / view / parser, add a line to
  `docs/ROADMAP.md` so the next contributor knows it's done.
- Don't introduce new top-level dependencies without a brief note on
  why something already pulled in won't do.

## Code style

- TypeScript strict mode is on. Don't widen types to silence errors.
- No `any` without a comment explaining why.
- Comments explain *why*, not *what*. The code should already say what.
- **Important:** don't put `*/` inside a `/* ... */` block comment. (Ask
  me how I know.)

## Code of conduct

Be kind. Assume good intent. If a PR is rejected, the rejection is about
the change, not you.

## License

By contributing you agree that your contributions will be MIT-licensed,
matching the rest of the repository.
