# OpenClaw Architect 🦞🔍

> An architectural visualization tool for [OpenClaw](https://github.com/openclaw/openclaw) — parse the codebase, generate interactive diagrams, understand the system.

[![Status](https://img.shields.io/badge/status-early--scaffold-orange)](#project-status)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%E2%89%A520-brightgreen)](https://nodejs.org)

---

## What this is

OpenClaw is a personal-AI-assistant Gateway with a hub-and-spoke architecture: a control-plane Gateway, an agent runtime (the "Pi" engine), channel adapters for two-dozen-plus messaging surfaces (WhatsApp, Telegram, Discord, Slack, iMessage, ...), a Canvas server, prompt-injection files (`AGENTS.md`, `SOUL.md`, `TOOLS.md`), and a plugin system. It's a lot.

**OpenClaw Architect** parses an OpenClaw checkout and renders interactive diagrams so a new contributor (or you, six months from now) can actually see what's going on.

## Project status

This is an **early-stage scaffold**, not a finished product. Being honest about that upfront matters more than looking impressive.

| Area | Status | Notes |
|---|---|---|
| Markdown config parser (`AGENTS.md`, `SOUL.md`, `TOOLS.md`, `MEMORY.md`) | ✅ Working | Real implementation in `packages/parser` |
| `package.json` / workspace parser | ✅ Working | Extracts dependencies, workspaces, plugins |
| Component model + JSON architecture export | ✅ Working | The core data model is real |
| CLI: `architect scan <path>` | ✅ Working | Produces an architecture JSON file |
| Web visualizer: System Architecture diagram | ✅ Working | Interactive, zoom/pan, node details |
| Web visualizer: other 5 diagram types | 🟡 Stubbed | UI placeholders with "not yet implemented" |
| TypeScript / Python AST parsing | 🟡 Stubbed | Interface defined; implementation TODO |
| Export to SVG / PNG | ✅ Working | Via browser download |
| Export to Mermaid / PlantUML / PDF | 🟡 Stubbed | Format adapters scaffolded |
| Git history integration | ❌ Not started | Listed as future work |
| Real-time collab, AI insights, VS Code ext | ❌ Not started | Bonus features in spec, deliberately deferred |

If you came here expecting a polished product because the spec was ambitious — sorry. A scaffold that's honest about its scope is more useful than 6,000 lines of half-working code.

## Quick start

```bash
# Install
git clone https://github.com/joonnyip/openclaw-architect.git
cd openclaw-architect
pnpm install

# Scan an OpenClaw checkout (or use the bundled sample)
pnpm architect scan ./examples/sample-openclaw-project --out ./architecture.json

# Launch the web visualizer
pnpm dev
# → opens http://localhost:5173, auto-loads architecture.json
```

## How it works

```
┌─────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  OpenClaw repo  │ ──▶ │  packages/parser │ ──▶ │ architecture.json│
│   (filesystem)  │     │   (TS, Node 20+) │     │  (typed schema)  │
└─────────────────┘     └──────────────────┘     └────────┬─────────┘
                                                           │
                        ┌──────────────────┐               │
                        │  packages/web    │ ◀─────────────┘
                        │  (React + Flow)  │
                        └──────────────────┘
```

The parser produces a single typed JSON document describing components, edges, channels, agents, tools, and metadata. The web app is a thin renderer over that document — meaning anyone can write an alternative renderer (Mermaid, PlantUML, a CLI ASCII view) without touching the parser.

## Repo layout

```
openclaw-architect/
├── packages/
│   ├── parser/        # Core: scans an OpenClaw repo → architecture.json
│   ├── cli/           # `architect` command-line tool
│   └── web/           # React visualizer (Vite + React Flow)
├── examples/
│   └── sample-openclaw-project/   # Tiny fake OpenClaw repo for testing
├── docs/
│   ├── ARCHITECTURE.md            # How this tool itself is built
│   ├── SCHEMA.md                  # The architecture.json schema
│   └── ROADMAP.md                 # What's next
└── .github/workflows/             # CI (lint + test)
```

## Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — design of the tool itself
- [`docs/SCHEMA.md`](docs/SCHEMA.md) — the architecture JSON schema (the contract between parser and renderer)
- [`docs/ROADMAP.md`](docs/ROADMAP.md) — what's planned, what's deferred, what's deliberately out of scope
- [`CONTRIBUTING.md`](CONTRIBUTING.md) — how to add a parser, a visualization, or an export format

## Why a scaffold and not a finished tool?

The original spec called for: 6 visualization types, multi-language AST parsing (TS + JS + Python), 7 export formats, code editor integration, git history, plugin API, CLI, web app, real-time collab, AI insights, and a VS Code extension. That's realistically 4–8 weeks of focused work for a small team, not something that can be honestly delivered in one shot.

So this repo is structured so any of those pieces can be built incrementally without rewriting the foundation:

- **Parser plugins** (`packages/parser/src/parsers/`) — drop in a new file parser, register it, done.
- **Visualization plugins** (`packages/web/src/views/`) — each diagram is a self-contained React component reading from the same JSON.
- **Export adapters** (`packages/parser/src/exporters/`) — Mermaid, PlantUML, etc. each implement a tiny interface.

PRs welcome. See [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Author

Built by **Joon Nyip Koh**
- GitHub: [@joonnyip](https://github.com/joonnyip)
- LinkedIn: [Joon Nyip (Koh)](https://www.linkedin.com/in/joon-nyip-koh-6a219234/)

## License

MIT — see [`LICENSE`](LICENSE).

## Acknowledgements

OpenClaw is created by [Peter Steinberger](https://steipete.me) and contributors at [openclaw/openclaw](https://github.com/openclaw/openclaw). This tool has no affiliation with the OpenClaw project; it's a community visualization helper.
