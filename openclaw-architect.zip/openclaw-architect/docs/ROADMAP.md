# Roadmap

What's planned, what's deferred, what's deliberately out of scope.

## Now (v0.1 — this release)

- ✅ Markdown config parser
- ✅ `package.json` parser  
- ✅ Heuristic component discovery
- ✅ JSON + Mermaid export
- ✅ CLI (`scan`, `export`)
- ✅ Standalone single-file HTML viewer
- ✅ Vite/React app scaffold with System Architecture view
- ✅ Sample synthetic OpenClaw project for testing

## Next (v0.2)

The single biggest gap is moving past directory-name heuristics.

- **TypeScript AST parser**. Use `@typescript-eslint/parser` to extract
  imports, exports, and call graphs. Source location should be populated
  on every component (currently only `path` is set).
- **Python AST parser** for any `.py` files in the repo. The `ast` module
  in stdlib is enough.
- **Real `imports` edges**. Once we have ASTs, draw module dependency
  graphs that aren't synthesized from layout.
- **Dependency Graph view** in the web UI. Stub today; would render the
  edges from above.

## Later (v0.3+)

In rough priority order:

- **PlantUML export**. Format adapter exists as a stub; needs implementation.
- **Standalone HTML export from CLI** (different from the standalone viewer
  — this would inline the architecture data and ship a single file).
- **Agent Workflow view**. Reads `AGENTS.md` sections and the runtime
  components to draw the message → context → tool → response loop.
- **Multi-Agent Map view**. Reads agent definitions and session routing
  rules.
- **Plugin Architecture view**. Categorises plugins by type
  (channel/memory/tool/provider) and shows isolation boundaries.
- **Security Model view**. Mapping `dmPolicy`, sandbox modes, and
  per-channel auth from `openclaw.json`.
- **Themes** (light, high-contrast, colorblind-friendly). Currently dark only.
- **PDF export**. Probably via Puppeteer in the CLI.

## Bonus (no commitment)

These were in the original spec but are big enough that they belong as
separate projects:

- Real-time collaboration (multiple users on one diagram)
- Version comparison (architecture diff between two scans)
- AI-powered suggestions ("you have a circular dependency here")
- GitHub Action for auto-generation on commit
- VS Code extension for inline visualization

## Out of scope

- **Editing**. This tool reads architectures, it doesn't modify the
  source repo.
- **Deployment topology**. We model code structure, not runtime
  infrastructure. If you want infra diagrams, use Diagrams (Python) or
  Structurizr.
- **A built-in OpenClaw client**. We're an inspector for OpenClaw repos,
  not a fork or competitor.
