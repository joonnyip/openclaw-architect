# Architecture (of this tool)

How OpenClaw Architect itself is built. For the schema of the documents it
*produces*, see [`SCHEMA.md`](SCHEMA.md).

## High-level

```
   ┌──────────────┐    parser     ┌────────────────────┐   renderer    ┌────────┐
   │  OpenClaw    │ ────────────▶ │  architecture.json │ ────────────▶ │   UI   │
   │  checkout    │               │  (typed schema)    │               │ (web/  │
   │  (filesystem)│               │                    │               │  CLI)  │
   └──────────────┘               └────────────────────┘               └────────┘
```

Two design rules:

1. **The JSON document is the contract.** The parser and any renderer are
   only allowed to talk through it. This means anyone can write an
   alternative renderer (Mermaid CLI, Mermaid output is in fact the first
   one) without touching the parser, and vice versa.
2. **The parser is best-effort, never fatal.** Missing files become
   `warnings`, not exceptions. You can point this at a half-built repo
   and still get useful output.

## Packages

```
openclaw-architect/
├── packages/
│   ├── parser/    @openclaw-architect/parser  (the working core)
│   ├── cli/       @openclaw-architect/cli     (architect command)
│   └── web/       @openclaw-architect/web     (Vite + React + React Flow)
├── examples/
│   └── sample-openclaw-project/   (synthetic test repo)
└── docs/
```

### `packages/parser`

Zero-runtime-dependency TypeScript library (well, except `fast-glob`).
Pure functions where possible. Public surface:

- `scanRepository(path, opts?)` → `Architecture`
- `parseConfigFile(path)` → `ConfigDocument | null`
- `parsePackageJson(path)` → `ParsedPackageJson | null`
- `discoverComponents(path)` → `{ components, edges }`
- `exportArchitecture(arch, format)` → `string`

Internals are split by responsibility:

- `schema.ts` — the typed `Architecture` interface
- `markdown-config.ts` — `AGENTS.md` / `SOUL.md` / `TOOLS.md` / `MEMORY.md`
- `package-json.ts` — npm manifest extraction
- `discovery.ts` — directory-layout heuristics → components + edges
- `scanner.ts` — orchestrator, builds the final `Architecture` document
- `exporters.ts` — JSON, Mermaid, plus stubs for PlantUML / HTML

### `packages/cli`

Tiny CLI (no `commander` dependency on purpose — argv parsing is ~30
lines). Two commands:

- `architect scan <path>` — scan a repo, output JSON or Mermaid
- `architect export <arch.json>` — convert an existing scan

### `packages/web`

Two parallel implementations on purpose:

- `standalone.html` — single file, CDN-loaded React + React Flow + dagre.
  Open by double-click. Loads `architecture.json` either via file picker
  or by fetching `sample-architecture.json` from the same directory.
- Vite app (`src/`) — proper React + TypeScript dev environment.
  `pnpm dev` to run.

Both render the same `Architecture` schema. The standalone is for quick
preview / sharing, the Vite app is for development and richer features.

## Why a JSON intermediate

The original spec asked for six visualization types and seven export
formats. That's a 6×7 = 42 implementation matrix if you go straight from
parser to output. With the intermediate JSON it's 6 + 7 = 13 — and any
new visualization or export is an additive change.

It also means non-TypeScript renderers can exist (a Python script
generating Diagrams output, an Obsidian plugin reading the JSON, etc).

## Why directory heuristics, not AST parsing

Two reasons:

1. **AST parsing is expensive to do well across TS/JS/Python.** Doing it
   *badly* would produce confidently-wrong diagrams, which is worse than
   the no-diagram alternative.
2. **Directory layout already encodes most of what a top-level diagram
   needs.** OpenClaw's convention of `apps/gateway`, `packages/channel-*`,
   `apps/{macos,ios,android}` is informative enough to render an accurate
   System Architecture view.

AST parsing is on the roadmap (see [`ROADMAP.md`](ROADMAP.md)) for the
Component Dependency view, where it actually matters.

## Why the standalone HTML

A `pnpm install` failure shouldn't be the thing that stops someone from
seeing what this tool produces. The standalone file is also useful for
sharing diagrams — generate the JSON, ship the JSON next to the HTML,
recipient opens one file in a browser.
