# Architecture Schema

The contract between the parser and any renderer (web, CLI, alternative
tools) is a single JSON document conforming to the `Architecture` interface
in [`packages/parser/src/schema.ts`](../packages/parser/src/schema.ts).

That file is the authoritative spec — this doc is the human-readable tour.

## Top-level shape

```ts
interface Architecture {
  schemaVersion: "0.1.0";
  scannedAt: string;            // ISO 8601 timestamp
  repoPath: string;             // absolute path that was scanned
  repoName: string;             // from package.json or directory name
  components: Component[];
  edges: Edge[];
  configDocuments: ConfigDocument[];
  warnings: ScanWarning[];
  stats: {
    componentCount: number;
    edgeCount: number;
    configFileCount: number;
    scanDurationMs: number;
  };
}
```

## Components

A `Component` is anything the renderer might want to draw as a node.

```ts
interface Component {
  id: string;          // stable, slug-like, safe for URLs/DOM ids
  name: string;        // human-readable
  kind: ComponentKind; // see below
  description?: string;
  path?: string;       // relative to repo root
  sourceLocation?: { file: string; line?: number };
  metadata?: Record<string, unknown>;
  children?: string[]; // ids of nested components
}
```

### ComponentKind

| Kind | What it is |
|---|---|
| `gateway` | Control-plane Gateway server |
| `agent-runtime` | Pi engine / agent execution layer |
| `channel-adapter` | WhatsApp, Telegram, Discord, Slack, etc. |
| `control-interface` | Web UI, CLI, macOS app, mobile node |
| `canvas` | Canvas rendering server |
| `plugin` | Loadable plugin |
| `tool` | A tool the agent can invoke |
| `skill` | Skill bundle |
| `config-file` | AGENTS.md, SOUL.md, TOOLS.md, MEMORY.md, *.json |
| `external-service` | Third-party dependency |
| `unknown` | Detected but unclassified |

## Edges

```ts
interface Edge {
  id: string;
  source: string;   // Component.id
  target: string;   // Component.id
  kind: EdgeKind;
  label?: string;
  metadata?: Record<string, unknown>;
}
```

### EdgeKind

| Kind | Meaning |
|---|---|
| `depends-on` | npm or python dependency |
| `imports` | module-level import (currently unused — needs AST parsing) |
| `configures` | config file → component |
| `routes-to` | gateway → agent / agent → tool |
| `channels` | channel adapter ↔ gateway (bidirectional in renderer) |
| `uses-tool` | agent → tool invocation |
| `loads-plugin` | host → plugin |

## Config documents

Parsed contents of conventional Markdown files (`AGENTS.md`, `SOUL.md`,
`TOOLS.md`, `MEMORY.md`).

```ts
interface ConfigDocument {
  path: string;
  type: "AGENTS.md" | "SOUL.md" | "TOOLS.md" | "MEMORY.md"
      | "package.json" | "session.json" | "other";
  sections: Record<string, string> | null;  // keyed by slugified heading
  headings?: string[];                       // raw headings, in order
  warnings?: string[];
}
```

Sections are split on `##` and `###` headings. Content before the first
heading lands under the synthetic key `_intro`. Duplicate heading slugs get
`-2`, `-3`, ... suffixes to avoid collisions.

## Warnings

Non-fatal issues encountered during the scan. Renderers should surface
these to the user.

```ts
interface ScanWarning {
  level: "info" | "warn" | "error";
  message: string;
  path?: string;
}
```

## Versioning

`schemaVersion` follows semver. Bump the major when removing fields or
changing types incompatibly; bump the minor when adding optional fields;
patch for clarifications.
