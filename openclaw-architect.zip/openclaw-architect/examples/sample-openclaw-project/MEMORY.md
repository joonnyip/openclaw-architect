# Memory

Memory configuration for this workspace.

## Strategy

Rolling summary: last 50 messages kept verbatim, older messages compacted into a topic-keyed summary block at session start.

## Persistence

`~/.openclaw/workspace/memory/<agent-id>.json`
