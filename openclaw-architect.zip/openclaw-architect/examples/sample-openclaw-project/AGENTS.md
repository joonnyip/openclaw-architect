# Agents

Definitions for the agents available in this workspace.

## Main

The default personal-assistant agent. Handles direct messages, voice input, and any inbound channel traffic that isn't routed to a specialist.

- Model: `anthropic/claude-opus-4-7`
- Sandbox: `none` (full host access — main session only)
- Tools: bash, browser, canvas, sessions

## Researcher

A specialist agent for deep research tasks. Spawned by the main agent when a query needs sustained web search and synthesis.

- Model: `anthropic/claude-opus-4-7`
- Sandbox: `docker`
- Tools: browser, web-search, sessions

## Inbox-Triage

Runs on a cron schedule. Reads recent messages across channels, summarizes, and posts a daily digest.

- Model: `anthropic/claude-haiku-4-5`
- Sandbox: `docker`
- Schedule: `0 8 * * *`
