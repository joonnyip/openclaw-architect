# Tools

Tools available to agents in this workspace.

## bash

Executes shell commands. Sandboxed for non-main sessions.

## browser

Headless Chromium for web navigation and scraping.

## web-search

Wraps the configured search provider (default: DuckDuckGo).

## canvas

Renders structured UI to the live Canvas surface.

## sessions

Spawn, list, and message other agent sessions.
