# Honest State

What actually works in this scaffold, what's stubbed, what wasn't tested.
Better to read this than be surprised.

## Verified working

- **`@openclaw-architect/parser`** — all source compiles, scanner runs end-to-end
  on the bundled sample repo: 24 components, 15 edges, 4 config files
  detected in ~300ms.
- **Markdown config parser** — 5/5 unit tests pass.
  Run them yourself: `cd packages/parser && pnpm test`
- **`@openclaw-architect/cli`** — both `architect scan` and `architect export`
  work. The `examples/sample-architecture.json` file in this repo was
  produced by the CLI and is kept as a regression check.
- **Mermaid export** — generates valid `flowchart LR` syntax. Paste the
  output into <https://mermaid.live> to verify.

## Built but not browser-tested

- **`packages/web/standalone.html`** — single-file React + React Flow viewer.
  Loads dependencies from a CDN via importmap, so it should work by
  double-clicking the file (or via any static server). I wrote it carefully,
  but I never opened it in a real browser. Expect rough edges; file an
  issue if something breaks.
- **`packages/web/` (Vite app)** — full Vite + React + TypeScript app with
  banded layout and detail panel. Builds were not run; `pnpm install` was
  not exercised. Should work; treat as alpha.

## Stubbed deliberately

These have UI/CLI surface but throw or show "not yet implemented":

- Five of the six visualization tabs (Component Dependencies, Agent Workflow,
  Multi-Agent Map, Plugin Architecture, Security Model) — render placeholder
  views explaining what they'd show.
- `exportPlantUml()` and `exportStandaloneHtml()` exporters — throw with a
  clear message pointing to the roadmap.
- TypeScript / Python AST parsing — only directory-name heuristics so far.

## Not built

- `docs/ARCHITECTURE.md`, `docs/SCHEMA.md`, `docs/ROADMAP.md`,
  `CONTRIBUTING.md` — referenced in the README, not written. Sorry.
- `.github/workflows/ci.yml` — directory created, no workflow.
- Git history integration, real-time collab, AI insights, VS Code
  extension — explicitly deferred from the original spec.

## Quick win path if you're picking this up

1. `cd packages/parser && npm install && npm test` — proves the foundation.
2. `cd packages/cli && npm install && npx tsx src/index.ts scan ../../examples/sample-openclaw-project --out arch.json`
3. Copy `arch.json` next to `packages/web/standalone.html` as
   `sample-architecture.json`, open the HTML in a browser, click
   "Load sample architecture".
4. If the visualizer works for you, write the docs I didn't get to and
   send a PR.
