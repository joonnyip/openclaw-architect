#!/usr/bin/env node
/**
 * `architect` CLI.
 *
 * Subcommands:
 *   scan <path> [--out file] [--format json|mermaid]   Scan a repo.
 *   export <arch.json> --format mermaid|plantuml|html  Convert an existing scan.
 *   help                                                Show this help.
 *
 * Deliberately uses no argument-parsing library — it's a tiny CLI and a
 * dependency for this would be silly. If options grow, reach for `commander`.
 */

import { writeFile, readFile } from "node:fs/promises";
import path from "node:path";
import {
  scanRepository,
  exportArchitecture,
  type ExportFormat,
  type Architecture,
} from "@openclaw-architect/parser";

const HELP = `OpenClaw Architect — architectural visualization tool

Usage:
  architect scan <path> [--out <file>] [--format json|mermaid]
  architect export <architecture.json> --format mermaid|plantuml|html [--out <file>]
  architect help

Examples:
  architect scan ./openclaw --out architecture.json
  architect scan ./openclaw --format mermaid
  architect export architecture.json --format mermaid --out diagram.mmd

Project: https://github.com/joonnyip/openclaw-architect
`;

interface ParsedArgs {
  command: string;
  positional: string[];
  flags: Record<string, string | boolean>;
}

function parseArgs(argv: string[]): ParsedArgs {
  const [command = "help", ...rest] = argv;
  const positional: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < rest.length; i++) {
    const tok = rest[i]!;
    if (tok.startsWith("--")) {
      const key = tok.slice(2);
      const next = rest[i + 1];
      if (next && !next.startsWith("--")) {
        flags[key] = next;
        i++;
      } else {
        flags[key] = true;
      }
    } else {
      positional.push(tok);
    }
  }
  return { command, positional, flags };
}

function isExportFormat(s: string): s is ExportFormat {
  return ["json", "mermaid", "plantuml", "html"].includes(s);
}

async function cmdScan(args: ParsedArgs): Promise<void> {
  const target = args.positional[0];
  if (!target) {
    console.error("error: scan requires a path argument");
    console.error("usage: architect scan <path> [--out <file>] [--format json|mermaid]");
    process.exit(2);
  }

  const formatRaw = (args.flags.format as string) ?? "json";
  if (!isExportFormat(formatRaw)) {
    console.error(`error: unknown format "${formatRaw}"`);
    console.error("supported: json, mermaid, plantuml, html");
    process.exit(2);
  }

  console.error(`scanning ${path.resolve(target)}...`);
  let arch: Architecture;
  try {
    arch = await scanRepository(target);
  } catch (err) {
    console.error(`scan failed: ${(err as Error).message}`);
    process.exit(1);
  }

  console.error(
    `found ${arch.stats.componentCount} components, ${arch.stats.edgeCount} edges, ` +
      `${arch.stats.configFileCount} config files in ${arch.stats.scanDurationMs}ms`,
  );
  for (const w of arch.warnings) {
    const prefix = w.level === "error" ? "✗" : w.level === "warn" ? "!" : "i";
    console.error(`  ${prefix} ${w.message}`);
  }

  const output = exportArchitecture(arch, formatRaw);
  const out = args.flags.out as string | undefined;
  if (out) {
    await writeFile(out, output, "utf8");
    console.error(`wrote ${out}`);
  } else {
    process.stdout.write(output);
    if (!output.endsWith("\n")) process.stdout.write("\n");
  }
}

async function cmdExport(args: ParsedArgs): Promise<void> {
  const inputFile = args.positional[0];
  const formatRaw = args.flags.format as string | undefined;
  if (!inputFile || !formatRaw) {
    console.error("error: export requires <architecture.json> --format <fmt>");
    process.exit(2);
  }
  if (!isExportFormat(formatRaw)) {
    console.error(`error: unknown format "${formatRaw}"`);
    process.exit(2);
  }

  let arch: Architecture;
  try {
    const text = await readFile(inputFile, "utf8");
    arch = JSON.parse(text);
  } catch (err) {
    console.error(`could not read ${inputFile}: ${(err as Error).message}`);
    process.exit(1);
  }

  let output: string;
  try {
    output = exportArchitecture(arch, formatRaw);
  } catch (err) {
    console.error(`export failed: ${(err as Error).message}`);
    process.exit(1);
  }

  const out = args.flags.out as string | undefined;
  if (out) {
    await writeFile(out, output, "utf8");
    console.error(`wrote ${out}`);
  } else {
    process.stdout.write(output);
    if (!output.endsWith("\n")) process.stdout.write("\n");
  }
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  switch (args.command) {
    case "scan":
      await cmdScan(args);
      break;
    case "export":
      await cmdExport(args);
      break;
    case "help":
    case "--help":
    case "-h":
      process.stdout.write(HELP);
      break;
    default:
      console.error(`unknown command: ${args.command}`);
      process.stdout.write(HELP);
      process.exit(2);
  }
}

main().catch((err) => {
  console.error("unexpected error:", err);
  process.exit(1);
});
