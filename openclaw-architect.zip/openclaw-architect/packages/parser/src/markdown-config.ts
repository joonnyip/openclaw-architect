/**
 * Markdown config parser.
 *
 * OpenClaw uses several conventional Markdown files as agent configuration:
 *   - AGENTS.md — agent definitions
 *   - SOUL.md   — agent personality
 *   - TOOLS.md  — available tools
 *   - MEMORY.md — memory configuration
 *
 * We parse them as section-trees keyed by their level-2 headings, which is
 * how OpenClaw conventionally structures them. We do NOT attempt to
 * interpret the prose — that's the agent's job, not ours.
 */

import { readFile } from "node:fs/promises";
import path from "node:path";
import type { ConfigDocument } from "./schema.js";

const KNOWN_FILES = ["AGENTS.md", "SOUL.md", "TOOLS.md", "MEMORY.md"] as const;
type KnownFile = (typeof KNOWN_FILES)[number];

function isKnownFile(name: string): name is KnownFile {
  return (KNOWN_FILES as readonly string[]).includes(name);
}

/**
 * Split a markdown document into sections by ## headings.
 * Content before the first heading is stored under the key "_intro".
 *
 * Headings are normalised: lowercased, non-alphanumerics → "-", trimmed.
 * Duplicate normalised headings get a numeric suffix to avoid collision.
 */
export function splitMarkdownSections(markdown: string): {
  sections: Record<string, string>;
  headings: string[];
} {
  const lines = markdown.split(/\r?\n/);
  const sections: Record<string, string> = {};
  const headings: string[] = [];
  const seenKeys = new Map<string, number>();

  let currentKey = "_intro";
  let currentRawHeading = "";
  let buffer: string[] = [];

  const flush = () => {
    if (buffer.length === 0 && currentKey === "_intro") return;
    const content = buffer.join("\n").trim();
    if (currentKey === "_intro" && content === "") return;

    let key = currentKey;
    const seen = seenKeys.get(key) ?? 0;
    if (seen > 0) key = `${key}-${seen + 1}`;
    seenKeys.set(currentKey, seen + 1);

    sections[key] = content;
    if (currentRawHeading) headings.push(currentRawHeading);
  };

  for (const line of lines) {
    // Match ## or ### headings (## is the primary structural level)
    const match = /^(#{2,3})\s+(.+?)\s*$/.exec(line);
    if (match) {
      flush();
      currentRawHeading = match[2]!;
      currentKey = slugify(currentRawHeading);
      buffer = [];
      continue;
    }
    buffer.push(line);
  }
  flush();

  return { sections, headings };
}

function slugify(text: string): string {
  return (
    text
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, "-")
      .replace(/^-+|-+$/g, "") || "section"
  );
}

/**
 * Read and parse a single known config file. Returns null if the file
 * doesn't exist or isn't readable — callers decide whether that's an error.
 */
export async function parseConfigFile(
  filePath: string,
): Promise<ConfigDocument | null> {
  let raw: string;
  try {
    raw = await readFile(filePath, "utf8");
  } catch {
    return null;
  }

  const basename = path.basename(filePath);
  const type = isKnownFile(basename) ? basename : "other";

  const warnings: string[] = [];
  if (raw.trim() === "") {
    warnings.push("file is empty");
  }

  const { sections, headings } = splitMarkdownSections(raw);

  return {
    path: filePath,
    type,
    sections: Object.keys(sections).length === 0 ? null : sections,
    headings,
    warnings: warnings.length > 0 ? warnings : undefined,
  };
}

/** The names this parser knows how to interpret. */
export const KNOWN_CONFIG_FILES = KNOWN_FILES;
