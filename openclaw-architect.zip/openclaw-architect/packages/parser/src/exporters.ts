/**
 * Export adapters.
 *
 * Each adapter takes an Architecture and returns a string in some target
 * format. Only Mermaid is implemented for now — the others are stubs that
 * throw a clear "not yet implemented" error so callers fail loudly.
 */

import type { Architecture, Component } from "./schema.js";

export type ExportFormat = "json" | "mermaid" | "plantuml" | "html";

export function exportJson(arch: Architecture): string {
  return JSON.stringify(arch, null, 2);
}

/** Mermaid `flowchart LR` rendering of the architecture. Real implementation. */
export function exportMermaid(arch: Architecture): string {
  const lines: string[] = ["flowchart LR"];

  // Group components by kind for readable subgraphs.
  const byKind = new Map<string, Component[]>();
  for (const c of arch.components) {
    const arr = byKind.get(c.kind) ?? [];
    arr.push(c);
    byKind.set(c.kind, arr);
  }

  // Stable id helper — Mermaid ids must be alphanumeric-ish.
  const mermaidId = (id: string): string => `n_${id.replace(/[^a-zA-Z0-9]/g, "_")}`;

  // Emit subgraphs per kind (skip if only one component of that kind).
  for (const [kind, comps] of byKind) {
    if (comps.length === 1) {
      const c = comps[0]!;
      lines.push(`  ${mermaidId(c.id)}["${escapeMermaid(c.name)}"]`);
      continue;
    }
    lines.push(`  subgraph ${kind.replace(/-/g, "_")} ["${kind}"]`);
    for (const c of comps) {
      lines.push(`    ${mermaidId(c.id)}["${escapeMermaid(c.name)}"]`);
    }
    lines.push("  end");
  }

  // Edges.
  for (const e of arch.edges) {
    const arrow =
      e.kind === "channels"
        ? "<-->"
        : e.kind === "loads-plugin"
          ? "-.->"
          : "-->";
    const label = e.label ? `|${escapeMermaid(e.label)}|` : "";
    lines.push(
      `  ${mermaidId(e.source)} ${arrow}${label} ${mermaidId(e.target)}`,
    );
  }

  return lines.join("\n");
}

function escapeMermaid(s: string): string {
  return s.replace(/"/g, "&quot;").replace(/\n/g, " ");
}

/** STUB — see ROADMAP.md. */
export function exportPlantUml(_arch: Architecture): string {
  throw new Error(
    "PlantUML export not yet implemented. " +
      "Tracking issue: https://github.com/joonnyip/openclaw-architect/issues (file one if you'd like to contribute).",
  );
}

/** STUB — see ROADMAP.md. */
export function exportStandaloneHtml(_arch: Architecture): string {
  throw new Error(
    "Standalone HTML export not yet implemented. " +
      "Use the web visualizer for now: pnpm dev → File → Export → SVG/PNG.",
  );
}

/** Dispatch helper. */
export function exportArchitecture(
  arch: Architecture,
  format: ExportFormat,
): string {
  switch (format) {
    case "json":
      return exportJson(arch);
    case "mermaid":
      return exportMermaid(arch);
    case "plantuml":
      return exportPlantUml(arch);
    case "html":
      return exportStandaloneHtml(arch);
  }
}
