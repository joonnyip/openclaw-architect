/**
 * package.json parser.
 *
 * Pulls out the bits we care about for architecture diagrams: the package
 * name, declared dependencies, workspace members, and any OpenClaw-specific
 * fields (plugins, channels, tools) that show up as conventional keys.
 */

import { readFile } from "node:fs/promises";

export interface ParsedPackageJson {
  name?: string;
  version?: string;
  description?: string;
  /** Combined runtime + dev dependencies (with a flag noting which is which). */
  dependencies: Array<{ name: string; version: string; dev: boolean }>;
  /** Workspace globs from `workspaces` (array form or { packages: [...] }). */
  workspaces: string[];
  /**
   * OpenClaw plugins declared in the manifest. We look at a few conventional
   * spots — projects vary, so we collect leniently and let the renderer
   * decide what to do with them.
   */
  declaredPlugins: string[];
  /** Anything else we don't recognise — kept verbatim for forward compat. */
  raw: unknown;
}

export async function parsePackageJson(
  filePath: string,
): Promise<ParsedPackageJson | null> {
  let text: string;
  try {
    text = await readFile(filePath, "utf8");
  } catch {
    return null;
  }

  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    return null;
  }

  if (typeof json !== "object" || json === null) return null;
  const obj = json as Record<string, unknown>;

  const dependencies: ParsedPackageJson["dependencies"] = [];
  const collect = (
    field: "dependencies" | "devDependencies",
    dev: boolean,
  ) => {
    const raw = obj[field];
    if (typeof raw !== "object" || raw === null) return;
    for (const [name, version] of Object.entries(raw as object)) {
      if (typeof version === "string") {
        dependencies.push({ name, version, dev });
      }
    }
  };
  collect("dependencies", false);
  collect("devDependencies", true);

  let workspaces: string[] = [];
  const ws = obj.workspaces;
  if (Array.isArray(ws)) {
    workspaces = ws.filter((x): x is string => typeof x === "string");
  } else if (typeof ws === "object" && ws !== null) {
    const packages = (ws as { packages?: unknown }).packages;
    if (Array.isArray(packages)) {
      workspaces = packages.filter((x): x is string => typeof x === "string");
    }
  }

  // Conventional places projects list OpenClaw plugins.
  const declaredPlugins: string[] = [];
  const candidates = [
    obj.openclaw,
    (obj as Record<string, unknown>)["openclaw-plugins"],
  ];
  for (const c of candidates) {
    if (Array.isArray(c)) {
      for (const v of c) if (typeof v === "string") declaredPlugins.push(v);
    } else if (typeof c === "object" && c !== null) {
      const p = (c as { plugins?: unknown }).plugins;
      if (Array.isArray(p)) {
        for (const v of p) if (typeof v === "string") declaredPlugins.push(v);
      }
    }
  }

  return {
    name: typeof obj.name === "string" ? obj.name : undefined,
    version: typeof obj.version === "string" ? obj.version : undefined,
    description:
      typeof obj.description === "string" ? obj.description : undefined,
    dependencies,
    workspaces,
    declaredPlugins,
    raw: json,
  };
}
