/**
 * Top-level scanner. Given a path to an OpenClaw checkout (or anything that
 * looks like one), produces an Architecture document.
 *
 * This is intentionally "best effort" — missing files become warnings, not
 * errors. The goal is that you can point this at half-built repos and still
 * get something useful out.
 */

import path from "node:path";
import { stat } from "node:fs/promises";
import fg from "fast-glob";
import {
  type Architecture,
  type Component,
  type ConfigDocument,
  type Edge,
  type ScanWarning,
  SCHEMA_VERSION,
} from "./schema.js";
import { discoverComponents } from "./discovery.js";
import {
  KNOWN_CONFIG_FILES,
  parseConfigFile,
} from "./markdown-config.js";
import { parsePackageJson } from "./package-json.js";

export interface ScanOptions {
  /** Set of directory globs to ignore. Defaults are reasonable. */
  ignore?: string[];
}

const DEFAULT_IGNORES = [
  "**/node_modules/**",
  "**/dist/**",
  "**/build/**",
  "**/.git/**",
  "**/coverage/**",
  "**/.next/**",
  "**/.vite/**",
];

export async function scanRepository(
  repoPath: string,
  options: ScanOptions = {},
): Promise<Architecture> {
  const startTime = performance.now();
  const absolutePath = path.resolve(repoPath);
  const warnings: ScanWarning[] = [];

  // Sanity: does the path exist and is it a directory?
  try {
    const s = await stat(absolutePath);
    if (!s.isDirectory()) {
      throw new Error(`Not a directory: ${absolutePath}`);
    }
  } catch (err) {
    throw new Error(
      `Cannot scan ${absolutePath}: ${(err as Error).message}`,
    );
  }

  // 1. Component discovery via directory heuristics.
  const { components, edges } = await discoverComponents(absolutePath);
  if (components.length === 0) {
    warnings.push({
      level: "warn",
      message:
        "No components matched the discovery heuristics. " +
        "Either this isn't an OpenClaw-shaped repo, or its layout is unconventional. " +
        "An empty architecture will still be produced for inspection.",
    });
  }

  // 2. Find and parse known markdown config files.
  const configDocuments: ConfigDocument[] = [];
  for (const filename of KNOWN_CONFIG_FILES) {
    const matches = await fg(`**/${filename}`, {
      cwd: absolutePath,
      ignore: options.ignore ?? DEFAULT_IGNORES,
      absolute: true,
      followSymbolicLinks: false,
    });
    for (const match of matches) {
      const doc = await parseConfigFile(match);
      if (doc) {
        // Store relative paths for portability in the JSON output.
        doc.path = path.relative(absolutePath, match);
        configDocuments.push(doc);
      }
    }
  }

  // 3. Parse the root package.json for repo identity + dependency list.
  const rootPkg = await parsePackageJson(
    path.join(absolutePath, "package.json"),
  );
  const repoName =
    rootPkg?.name ?? path.basename(absolutePath) ?? "unknown-repo";

  // 4. If we have a root package.json, attach external-service nodes for
  //    dependencies that map onto things the renderer might want to highlight
  //    (this is intentionally conservative — dependency forests are huge).
  if (rootPkg) {
    const externalsOfInterest = rootPkg.dependencies
      .filter((d) => !d.dev)
      .filter((d) =>
        /^(@?openai|@?anthropic|@?google|elevenlabs|whatsapp|telegram|discord|slack)/i.test(
          d.name,
        ),
      );
    for (const dep of externalsOfInterest) {
      const id = `external:${dep.name.replace(/[@/]/g, "-")}`;
      components.push({
        id,
        name: dep.name,
        kind: "external-service",
        description: `External dependency (${dep.version})`,
        metadata: { version: dep.version },
      });
      // Link to gateway if we have one — it's the most common consumer.
      const gateway = components.find((c) => c.kind === "gateway");
      if (gateway) {
        edges.push({
          id: `edge:${gateway.id}->${id}`,
          source: gateway.id,
          target: id,
          kind: "depends-on",
          label: "uses",
        });
      }
    }
  }

  // 5. Attach config-file pseudo-components so they show up on the diagram.
  for (const doc of configDocuments) {
    const id = `config:${doc.path.replace(/[/\\]/g, "-")}`;
    const comp: Component = {
      id,
      name: path.basename(doc.path),
      kind: "config-file",
      description: `${doc.type} config`,
      path: doc.path,
      sourceLocation: { file: doc.path },
      metadata: { sectionCount: doc.sections ? Object.keys(doc.sections).length : 0 },
    };
    components.push(comp);
  }

  if (configDocuments.length === 0) {
    warnings.push({
      level: "info",
      message:
        "No conventional config files (AGENTS.md, SOUL.md, TOOLS.md, MEMORY.md) were found.",
    });
  }

  const scanDurationMs = Math.round(performance.now() - startTime);

  return {
    schemaVersion: SCHEMA_VERSION,
    scannedAt: new Date().toISOString(),
    repoPath: absolutePath,
    repoName,
    components,
    edges,
    configDocuments,
    warnings,
    stats: {
      componentCount: components.length,
      edgeCount: edges.length,
      configFileCount: configDocuments.length,
      scanDurationMs,
    },
  };
}

// Re-export edge type alias used by callers.
export type { Edge };
