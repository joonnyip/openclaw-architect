/**
 * Architecture schema.
 *
 * This is the single source of truth for what an "OpenClaw architecture"
 * looks like as data. The parser produces this; renderers consume it.
 *
 * Versioned via SCHEMA_VERSION below — bump on breaking changes.
 */

export const SCHEMA_VERSION = "0.1.0" as const;

/** Categories of components we recognise in an OpenClaw repo. */
export type ComponentKind =
  | "gateway" // The control-plane Gateway server
  | "agent-runtime" // The Pi engine / agent execution layer
  | "channel-adapter" // WhatsApp, Telegram, Discord, etc.
  | "control-interface" // Web UI, CLI, macOS app, mobile node
  | "canvas" // Canvas rendering server
  | "plugin" // Loadable plugin (channel/memory/tool/provider)
  | "tool" // A tool the agent can invoke
  | "skill" // A skill bundle (~/.openclaw/workspace/skills/*)
  | "config-file" // AGENTS.md, SOUL.md, TOOLS.md, MEMORY.md, *.json
  | "external-service" // A third-party service the system depends on
  | "unknown";

/** How two components relate. */
export type EdgeKind =
  | "depends-on" // npm/python dependency
  | "imports" // module-level import
  | "configures" // config file → component
  | "routes-to" // gateway → agent / agent → tool
  | "channels" // channel adapter ↔ gateway
  | "uses-tool" // agent → tool invocation
  | "loads-plugin"; // host → plugin

export interface Component {
  /** Stable, slug-like identifier — safe for use in URLs / DOM ids. */
  id: string;
  /** Human-readable name. */
  name: string;
  kind: ComponentKind;
  /** Short one-line description. */
  description?: string;
  /** Path relative to repo root where this component lives. */
  path?: string;
  /** Optional file:line for jump-to-source. */
  sourceLocation?: { file: string; line?: number };
  /** Free-form metadata — never assume these keys exist. */
  metadata?: Record<string, unknown>;
  /** Ids of nested components (e.g. plugins inside a plugin host). */
  children?: string[];
}

export interface Edge {
  id: string;
  source: string; // Component.id
  target: string; // Component.id
  kind: EdgeKind;
  label?: string;
  metadata?: Record<string, unknown>;
}

/** A parsed config file (AGENTS.md, SOUL.md, etc.). */
export interface ConfigDocument {
  path: string;
  /** Which file this is, by convention. */
  type:
    | "AGENTS.md"
    | "SOUL.md"
    | "TOOLS.md"
    | "MEMORY.md"
    | "package.json"
    | "session.json"
    | "other";
  /** Raw extracted sections — `null` if the file was empty / unparseable. */
  sections: Record<string, string> | null;
  /** Headings found, in order. Useful for rendering a table of contents. */
  headings?: string[];
  /** Parser warnings encountered. Non-fatal. */
  warnings?: string[];
}

/** A scan-time warning the user should probably see. */
export interface ScanWarning {
  level: "info" | "warn" | "error";
  message: string;
  path?: string;
}

/** The full architecture document. This is what gets serialised to JSON. */
export interface Architecture {
  schemaVersion: typeof SCHEMA_VERSION;
  /** When the scan ran (ISO 8601). */
  scannedAt: string;
  /** Absolute path of the repo that was scanned. */
  repoPath: string;
  /** Best-effort name pulled from package.json or directory name. */
  repoName: string;
  components: Component[];
  edges: Edge[];
  configDocuments: ConfigDocument[];
  warnings: ScanWarning[];
  /** Stats for quick at-a-glance. */
  stats: {
    componentCount: number;
    edgeCount: number;
    configFileCount: number;
    /** How long the scan took, in milliseconds. */
    scanDurationMs: number;
  };
}
