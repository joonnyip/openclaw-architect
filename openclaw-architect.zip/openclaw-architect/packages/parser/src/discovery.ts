// Component discovery.
//
// Heuristics for inferring OpenClaw component structure from a checkout's
// directory layout. We deliberately don't AST-parse anything yet -- that's
// a future phase. Right now we go on directory names and conventional file
// paths, which is enough to render a useful first diagram.
//
// Heuristics, in order of confidence:
//   1. apps/gateway, packages/gateway, src/gateway   -> "gateway"
//   2. (any)/channels/<n>, packages/channel-<n>      -> "channel-adapter"
//   3. (any)/plugins/<n>, packages/plugin-<n>        -> "plugin"
//   4. tools/, (any)/tools/<n>                       -> "tool"
//   5. skills/<n>                                    -> "skill"
//   6. apps/canvas, packages/canvas                  -> "canvas"
//   7. apps/{macos,ios,android,cli,web}              -> "control-interface"
//
// Anything else stays unmatched -- we'd rather under-classify than wrongly
// classify and mislead the renderer.

import path from "node:path";
import fg from "fast-glob";
import type { Component, Edge } from "./schema.js";

interface DiscoveryResult {
  components: Component[];
  edges: Edge[];
}

function slug(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "");
}

function prettify(s: string): string {
  return s
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

interface Pattern {
  glob: string;
  kind: Component["kind"];
  description: (name: string) => string;
}

const PATTERNS: Pattern[] = [
  { glob: "apps/gateway", kind: "gateway", description: () => "Control-plane Gateway server" },
  { glob: "packages/gateway", kind: "gateway", description: () => "Control-plane Gateway server" },
  { glob: "src/gateway", kind: "gateway", description: () => "Control-plane Gateway server" },
  { glob: "apps/canvas", kind: "canvas", description: () => "Canvas rendering server" },
  { glob: "packages/canvas", kind: "canvas", description: () => "Canvas rendering server" },
  { glob: "**/channels/*", kind: "channel-adapter", description: (n) => `${prettify(n)} channel adapter` },
  { glob: "packages/channel-*", kind: "channel-adapter", description: (n) => `${prettify(n.replace(/^channel-/, ""))} channel adapter` },
  { glob: "**/plugins/*", kind: "plugin", description: (n) => `${prettify(n)} plugin` },
  { glob: "packages/plugin-*", kind: "plugin", description: (n) => `${prettify(n.replace(/^plugin-/, ""))} plugin` },
  { glob: "tools/*", kind: "tool", description: (n) => `${prettify(n)} tool` },
  { glob: "**/tools/*", kind: "tool", description: (n) => `${prettify(n)} tool` },
  { glob: "skills/*", kind: "skill", description: (n) => `${prettify(n)} skill` },
  { glob: "apps/{macos,ios,android,cli,web,desktop,mobile}", kind: "control-interface", description: (n) => `${prettify(n)} control interface` },
  { glob: "apps/agent-runtime", kind: "agent-runtime", description: () => "Agent runtime (Pi engine)" },
  { glob: "packages/agent-runtime", kind: "agent-runtime", description: () => "Agent runtime (Pi engine)" },
  { glob: "packages/pi", kind: "agent-runtime", description: () => "Pi engine (agent runtime)" },
];

export async function discoverComponents(repoPath: string): Promise<DiscoveryResult> {
  const components: Component[] = [];
  const seenIds = new Set<string>();
  const addComponent = (c: Component) => {
    if (seenIds.has(c.id)) return;
    seenIds.add(c.id);
    components.push(c);
  };

  for (const pattern of PATTERNS) {
    const matches = await fg(pattern.glob, {
      cwd: repoPath,
      onlyDirectories: true,
      dot: false,
      followSymbolicLinks: false,
    });
    for (const match of matches) {
      const name = path.basename(match);
      const id = `${pattern.kind}:${slug(match)}`;
      addComponent({
        id,
        name: prettify(name),
        kind: pattern.kind,
        description: pattern.description(name),
        path: match,
      });
    }
  }

  // Synthesize edges from the topology we found.
  const edges: Edge[] = [];
  const gateway = components.find((c) => c.kind === "gateway");

  if (gateway) {
    for (const c of components) {
      if (c.kind === "channel-adapter") {
        edges.push({
          id: `edge:${c.id}->${gateway.id}`,
          source: c.id,
          target: gateway.id,
          kind: "channels",
          label: "channels",
        });
      }
    }
    const runtime = components.find((c) => c.kind === "agent-runtime");
    if (runtime) {
      edges.push({
        id: `edge:${gateway.id}->${runtime.id}`,
        source: gateway.id,
        target: runtime.id,
        kind: "routes-to",
        label: "routes",
      });
    }
    for (const c of components) {
      if (c.kind === "control-interface") {
        edges.push({
          id: `edge:${c.id}->${gateway.id}`,
          source: c.id,
          target: gateway.id,
          kind: "depends-on",
          label: "controls",
        });
      }
    }
    for (const c of components) {
      if (c.kind === "plugin") {
        edges.push({
          id: `edge:${gateway.id}->${c.id}`,
          source: gateway.id,
          target: c.id,
          kind: "loads-plugin",
          label: "loads",
        });
      }
    }
    const canvas = components.find((c) => c.kind === "canvas");
    if (canvas) {
      edges.push({
        id: `edge:${gateway.id}->${canvas.id}`,
        source: gateway.id,
        target: canvas.id,
        kind: "depends-on",
        label: "renders",
      });
    }
  }

  return { components, edges };
}
