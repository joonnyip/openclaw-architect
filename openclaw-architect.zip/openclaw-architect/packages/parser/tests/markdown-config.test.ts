import { test } from "node:test";
import assert from "node:assert/strict";
import { splitMarkdownSections } from "../src/markdown-config.ts";

test("splits sections by ## headings", () => {
  const md = `# Title

intro text

## Personality

calm, helpful

## Tools

bash, browser
`;
  const { sections, headings } = splitMarkdownSections(md);
  assert.equal(headings.length, 2);
  assert.deepEqual(headings, ["Personality", "Tools"]);
  assert.equal(sections._intro?.includes("intro text"), true);
  assert.equal(sections.personality, "calm, helpful");
  assert.equal(sections.tools, "bash, browser");
});

test("handles empty markdown", () => {
  const { sections, headings } = splitMarkdownSections("");
  assert.deepEqual(sections, {});
  assert.deepEqual(headings, []);
});

test("handles markdown with no headings", () => {
  const { sections, headings } = splitMarkdownSections("just some text\nmore text");
  assert.deepEqual(headings, []);
  assert.equal(sections._intro, "just some text\nmore text");
});

test("handles duplicate heading slugs", () => {
  const md = `## Setup

first

## Setup

second
`;
  const { sections } = splitMarkdownSections(md);
  assert.equal(sections.setup, "first");
  assert.equal(sections["setup-2"], "second");
});

test("ignores ### headings as section breaks but at level-3 still splits", () => {
  // Per design: we treat ## and ### as section breaks. This documents that.
  const md = `## Top

a

### Sub

b
`;
  const { headings } = splitMarkdownSections(md);
  assert.deepEqual(headings, ["Top", "Sub"]);
});
