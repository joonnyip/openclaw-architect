import type { Architecture, Component } from "@openclaw-architect/parser";

interface Props {
  architecture: Architecture;
  componentId: string;
  onClose: () => void;
}

export function DetailPanel({ architecture, componentId, onClose }: Props) {
  const component = architecture.components.find((c) => c.id === componentId);
  if (!component) return null;

  const incoming = architecture.edges.filter((e) => e.target === componentId);
  const outgoing = architecture.edges.filter((e) => e.source === componentId);
  const byId = new Map(architecture.components.map((c) => [c.id, c]));

  return (
    <aside className="detail">
      <button className="close" onClick={onClose} aria-label="Close detail panel">
        ×
      </button>
      <span className="kind-label">{component.kind}</span>
      <h3>{component.name}</h3>
      {component.description && (
        <p style={{ color: "var(--text-dim)", marginTop: 6 }}>
          {component.description}
        </p>
      )}

      {component.path && (
        <div className="field">
          <div className="field-label">Path</div>
          <code className="field-value code">{component.path}</code>
        </div>
      )}

      {component.metadata && Object.keys(component.metadata).length > 0 && (
        <div className="field">
          <div className="field-label">Metadata</div>
          <ul>
            {Object.entries(component.metadata).map(([k, v]) => (
              <li key={k}>
                <span style={{ color: "var(--text-faint)" }}>{k}:</span>{" "}
                {String(v)}
              </li>
            ))}
          </ul>
        </div>
      )}

      {incoming.length > 0 && (
        <div className="field">
          <div className="field-label">Incoming ({incoming.length})</div>
          <ul>
            {incoming.map((e) => {
              const src = byId.get(e.source);
              return (
                <li key={e.id}>
                  {src?.name ?? e.source}{" "}
                  <span style={{ color: "var(--text-faint)" }}>
                    — {e.kind}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {outgoing.length > 0 && (
        <div className="field">
          <div className="field-label">Outgoing ({outgoing.length})</div>
          <ul>
            {outgoing.map((e) => {
              const tgt = byId.get(e.target);
              return (
                <li key={e.id}>
                  {tgt?.name ?? e.target}{" "}
                  <span style={{ color: "var(--text-faint)" }}>
                    — {e.kind}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </aside>
  );
}

export function ComponentList({
  components,
  selectedId,
  onSelect,
}: {
  components: Component[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
      {components.map((c) => (
        <li key={c.id}>
          <button
            className={`view-button ${selectedId === c.id ? "active" : ""}`}
            onClick={() => onSelect(c.id)}
          >
            {c.name}
          </button>
        </li>
      ))}
    </ul>
  );
}
