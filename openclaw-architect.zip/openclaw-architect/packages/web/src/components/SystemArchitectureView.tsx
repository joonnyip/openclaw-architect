import { useMemo } from "react";
import ReactFlow, {
  Background,
  Controls,
  type Edge as RFEdge,
  type Node as RFNode,
  MarkerType,
} from "reactflow";
import type { Architecture, Component } from "@openclaw-architect/parser";
import { layoutByKind } from "../lib/layout";
import { ArchNode, type ArchNodeData } from "./ArchNode";

interface Props {
  architecture: Architecture;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}

const NODE_TYPES = { arch: ArchNode };

export function SystemArchitectureView({
  architecture,
  selectedId,
  onSelect,
}: Props) {
  const { nodes, edges } = useMemo(() => {
    const positions = layoutByKind(architecture.components);
    const posMap = new Map(positions.map((p) => [p.id, p.position]));

    const nodes: RFNode<ArchNodeData>[] = architecture.components.map(
      (c: Component): RFNode<ArchNodeData> => ({
        id: c.id,
        type: "arch",
        data: { component: c },
        position: posMap.get(c.id) ?? { x: 0, y: 0 },
        selected: c.id === selectedId,
      }),
    );

    const edges: RFEdge[] = architecture.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      label: e.label,
      animated: e.kind === "channels" || e.kind === "routes-to",
      markerEnd: {
        type: MarkerType.ArrowClosed,
        width: 14,
        height: 14,
      },
      style: e.kind === "loads-plugin" ? { strokeDasharray: "4 4" } : undefined,
    }));

    return { nodes, edges };
  }, [architecture, selectedId]);

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={NODE_TYPES}
      fitView
      fitViewOptions={{ padding: 0.15, maxZoom: 1.2 }}
      proOptions={{ hideAttribution: false }}
      onNodeClick={(_, node) => onSelect(node.id)}
      onPaneClick={() => onSelect(null)}
      minZoom={0.2}
      maxZoom={2}
    >
      <Background gap={24} size={1} color="#2c2823" />
      <Controls showInteractive={false} />
    </ReactFlow>
  );
}
