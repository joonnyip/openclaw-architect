import { Handle, Position, type NodeProps } from "reactflow";
import type { Component } from "@openclaw-architect/parser";

export interface ArchNodeData {
  component: Component;
}

const KIND_COLOR_VAR: Record<string, string> = {
  gateway: "var(--c-gateway)",
  "channel-adapter": "var(--c-channel)",
  "agent-runtime": "var(--c-agent)",
  "control-interface": "var(--c-control)",
  canvas: "var(--c-canvas)",
  plugin: "var(--c-plugin)",
  tool: "var(--c-tool)",
  skill: "var(--c-skill)",
  "config-file": "var(--c-config)",
  "external-service": "var(--c-external)",
  unknown: "var(--c-unknown)",
};

export function ArchNode({ data, selected }: NodeProps<ArchNodeData>) {
  const { component } = data;
  const accent = KIND_COLOR_VAR[component.kind] ?? "var(--c-unknown)";
  return (
    <div
      className={`rf-node ${selected ? "selected" : ""}`}
      style={{ borderLeftColor: accent }}
    >
      <Handle type="target" position={Position.Top} />
      <div className="name">{component.name}</div>
      <div className="kind" style={{ color: accent }}>
        {component.kind}
      </div>
      <Handle type="source" position={Position.Bottom} />
    </div>
  );
}
