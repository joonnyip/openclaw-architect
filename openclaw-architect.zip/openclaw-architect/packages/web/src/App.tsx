import { useRef, useState } from "react";
import { exportMermaid } from "@openclaw-architect/parser";
import { useArchitecture } from "./lib/useArchitecture";
import { SystemArchitectureView } from "./components/SystemArchitectureView";
import { DetailPanel } from "./components/DetailPanel";

type ViewId =
  | "system"
  | "dependencies"
  | "agent-workflow"
  | "multi-agent"
  | "plugins"
  | "security";

interface ViewDef {
  id: ViewId;
  label: string;
  implemented: boolean;
  description: string;
}

const VIEWS: ViewDef[] = [
  {
    id: "system",
    label: "System Architecture",
    implemented: true,
    description:
      "Hub-and-spoke view: gateway, channels, runtime, plugins, control surfaces.",
  },
  {
    id: "dependencies",
    label: "Dependency Graph",
    implemented: false,
    description:
      "Module-level import/export relationships. Requires the AST-parsing parser layer (Phase 2).",
  },
  {
    id: "agent-workflow",
    label: "Agent Workflow",
    implemented: false,
    description:
      "The message → context → model → tool → response loop, mapped from the agent runtime.",
  },
  {
    id: "multi-agent",
    label: "Multi-Agent Map",
    implemented: false,
    description:
      "Inter-agent routing, session ownership, and workspace sharing.",
  },
  {
    id: "plugins",
    label: "Plugin Architecture",
    implemented: false,
    description:
      "Plugin types (channel/memory/tool/provider), loading, and isolation boundaries.",
  },
  {
    id: "security",
    label: "Security & Permissions",
    implemented: false,
    description:
      "Access-control layers, sandbox vs full-access contexts, per-channel auth.",
  },
];

export function App() {
  const [{ architecture, error, loading }, loadFile] = useArchitecture();
  const [activeView, setActiveView] = useState<ViewId>("system");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onUpload: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      void loadFile(file);
      setSelectedId(null);
    }
  };

  const exportSvg = () => {
    const svgEl = document.querySelector(".react-flow__viewport") as SVGElement | null;
    const flowSvg = document.querySelector(".react-flow svg") as SVGElement | null;
    const target = flowSvg ?? svgEl;
    if (!target) {
      alert("Could not find the diagram SVG to export.");
      return;
    }
    const serialized = new XMLSerializer().serializeToString(target);
    const blob = new Blob([serialized], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${architecture?.repoName ?? "architecture"}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportMmd = () => {
    if (!architecture) return;
    const mmd = exportMermaid(architecture);
    const blob = new Blob([mmd], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${architecture.repoName}.mmd`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const activeViewDef = VIEWS.find((v) => v.id === activeView)!;
  const showDetail = !!architecture && !!selectedId && activeView === "system";

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <h1>
            <span className="crustacean">🦞</span>OpenClaw Architect
          </h1>
          <span className="tagline">
            {architecture ? architecture.repoName : "no repo loaded"}
          </span>
        </div>
        <div className="actions">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={onUpload}
            style={{ display: "none" }}
          />
          <button onClick={() => fileInputRef.current?.click()}>
            Load architecture.json
          </button>
          <button onClick={exportSvg} disabled={!architecture}>
            Export SVG
          </button>
          <button onClick={exportMmd} disabled={!architecture} className="primary">
            Export Mermaid
          </button>
        </div>
      </header>

      <div className={`body ${showDetail ? "" : "no-detail"}`}>
        <nav className="sidebar">
          <h2>Views</h2>
          {VIEWS.map((v) => (
            <button
              key={v.id}
              className={`view-button ${activeView === v.id ? "active" : ""}`}
              onClick={() => setActiveView(v.id)}
            >
              {v.label}
              {!v.implemented && <span className="badge">stub</span>}
            </button>
          ))}
        </nav>

        <main className="canvas">
          {loading && <div className="canvas-empty">Loading…</div>}

          {!loading && error && (
            <div className="canvas-empty">
              <div className="crustacean">😬</div>
              <h2>Couldn't load that file</h2>
              <p>{error}</p>
            </div>
          )}

          {!loading && !architecture && !error && <EmptyState />}

          {!loading && architecture && activeViewDef.implemented && (
            <>
              <SystemArchitectureView
                architecture={architecture}
                selectedId={selectedId}
                onSelect={setSelectedId}
              />
              <StatusBar architecture={architecture} />
              {architecture.warnings.length > 0 && (
                <div className="warnings">
                  {architecture.warnings.length} warning
                  {architecture.warnings.length === 1 ? "" : "s"} during scan —
                  see <code>warnings</code> in architecture.json
                </div>
              )}
            </>
          )}

          {!loading && architecture && !activeViewDef.implemented && (
            <ComingSoon view={activeViewDef} />
          )}
        </main>

        {showDetail && architecture && selectedId && (
          <DetailPanel
            architecture={architecture}
            componentId={selectedId}
            onClose={() => setSelectedId(null)}
          />
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="canvas-empty">
      <div className="crustacean">🦞</div>
      <h2>No architecture loaded</h2>
      <p>
        Generate one with the CLI, or load an existing <code>architecture.json</code>{" "}
        using the button above.
      </p>
      <pre>
{`# from the repo root
pnpm architect scan ./path/to/openclaw \\
  --out packages/web/public/architecture.json

# then refresh this page`}
      </pre>
    </div>
  );
}

function StatusBar({ architecture }: { architecture: NonNullable<ReturnType<typeof useArchitecture>[0]["architecture"]> }) {
  return (
    <div className="status">
      <span className="stat">
        <strong>{architecture.stats.componentCount}</strong> components
      </span>
      <span className="stat">
        <strong>{architecture.stats.edgeCount}</strong> edges
      </span>
      <span className="stat">
        <strong>{architecture.stats.configFileCount}</strong> configs
      </span>
      <span className="stat">
        scanned in <strong>{architecture.stats.scanDurationMs}ms</strong>
      </span>
    </div>
  );
}

function ComingSoon({ view }: { view: ViewDef }) {
  return (
    <div className="coming-soon">
      <span className="badge">Not yet implemented</span>
      <h2>{view.label}</h2>
      <p>{view.description}</p>
      <p style={{ marginTop: 16 }}>
        See <code>docs/ROADMAP.md</code> for the implementation plan, or grab
        the issue on GitHub.
      </p>
    </div>
  );
}
