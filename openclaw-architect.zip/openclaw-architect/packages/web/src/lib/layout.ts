/**
 * Layout helpers.
 *
 * Pulling in dagre or elkjs felt heavy for what we need. This hand-rolled
 * "kind-banded" layout is good enough for the System Architecture view:
 * we put each component-kind in a horizontal band, with the gateway in the
 * middle. It looks deliberate rather than spaghetti.
 *
 * If/when we add denser views, swap in dagre — the layout function is a
 * pure transform from (components, edges) → positions, so it's a clean
 * substitution.
 */

import type { Component, ComponentKind } from "@openclaw-architect/parser";

export interface LayoutNode {
  id: string;
  position: { x: number; y: number };
}

const ROW_HEIGHT = 130;
const COL_WIDTH = 220;

// The vertical band each kind sits in. Lower number = higher on screen.
// Channels at the top (inbound), gateway in the middle, runtime + outputs below.
const BAND_ORDER: ComponentKind[] = [
  "channel-adapter",
  "control-interface",
  "gateway",
  "agent-runtime",
  "plugin",
  "tool",
  "skill",
  "canvas",
  "external-service",
  "config-file",
  "unknown",
];

export function layoutByKind(components: Component[]): LayoutNode[] {
  // Group by kind, preserving input order within each group.
  const groups = new Map<ComponentKind, Component[]>();
  for (const c of components) {
    const arr = groups.get(c.kind) ?? [];
    arr.push(c);
    groups.set(c.kind, arr);
  }

  // Determine the visible band order: only include kinds that appear,
  // following BAND_ORDER for the canonical ones, then anything else after.
  const visibleBands: ComponentKind[] = [];
  for (const k of BAND_ORDER) if (groups.has(k)) visibleBands.push(k);
  for (const k of groups.keys())
    if (!visibleBands.includes(k)) visibleBands.push(k);

  // Lay each band out horizontally, centred.
  const nodes: LayoutNode[] = [];
  let y = 0;
  const maxBandWidth = Math.max(
    ...Array.from(groups.values()).map((g) => g.length),
  );
  const totalWidth = maxBandWidth * COL_WIDTH;

  for (const kind of visibleBands) {
    const band = groups.get(kind)!;
    const bandWidth = band.length * COL_WIDTH;
    const offsetX = (totalWidth - bandWidth) / 2;
    band.forEach((c, i) => {
      nodes.push({
        id: c.id,
        position: {
          x: offsetX + i * COL_WIDTH,
          y,
        },
      });
    });
    y += ROW_HEIGHT;
  }

  return nodes;
}
