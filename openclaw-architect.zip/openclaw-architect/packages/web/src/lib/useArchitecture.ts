import { useEffect, useState } from "react";
import type { Architecture } from "@openclaw-architect/parser";

export interface LoaderState {
  architecture: Architecture | null;
  error: string | null;
  loading: boolean;
}

/**
 * Tries to load an architecture document in this order:
 *   1. From a previously-uploaded file held in component state
 *   2. From `/architecture.json` at the site root (so users can drop a
 *      generated file in `packages/web/public/` and just refresh)
 *   3. Returns null if neither is available — UI shows the empty state.
 */
export function useArchitecture(): [
  LoaderState,
  (file: File) => Promise<void>,
] {
  const [state, setState] = useState<LoaderState>({
    architecture: null,
    error: null,
    loading: true,
  });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/architecture.json");
        if (!res.ok) {
          if (!cancelled)
            setState({ architecture: null, error: null, loading: false });
          return;
        }
        const data = (await res.json()) as Architecture;
        if (!cancelled)
          setState({ architecture: data, error: null, loading: false });
      } catch {
        if (!cancelled)
          setState({ architecture: null, error: null, loading: false });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadFile = async (file: File): Promise<void> => {
    setState((s) => ({ ...s, loading: true }));
    try {
      const text = await file.text();
      const data = JSON.parse(text) as Architecture;
      if (!data.schemaVersion || !Array.isArray(data.components)) {
        throw new Error(
          "File doesn't look like an architecture.json (missing schemaVersion or components)",
        );
      }
      setState({ architecture: data, error: null, loading: false });
    } catch (err) {
      setState({
        architecture: null,
        error: (err as Error).message,
        loading: false,
      });
    }
  };

  return [state, loadFile];
}
